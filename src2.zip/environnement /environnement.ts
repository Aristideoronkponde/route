export const environment = {
  production: true, // Indique si l'application est en mode production ou non. En mode production, des optimisations sont généralement activées et des fonctionnalités de développement sont désactivées.

  numberPage: 3, // Définit un paramètre spécifique à votre application, ici le nombre de pages, qui pourrait être utilisé pour la pagination ou la configuration de l'interface utilisateur.

  firebaseConfig: { // Contient la configuration nécessaire pour connecter votre application à Firebase, une plateforme mobile et web de Google.

    apiKey: 'AIzaSyChEUg7HCRV6b4bdnrAOI4ik-SoD2wv_2w', // Clé API pour accéder à l'API Firebase. Elle est utilisée pour authentifier les requêtes à Firebase.

    authDomain: 'app-music-e1542.firebaseapp.com', // Domaine d'authentification utilisé par Firebase Authentication pour gérer les utilisateurs.

    databaseURL: 'https://app-music-e1542-default-rtdb.europe-west1.firebasedatabase.app', // URL de la base de données en temps réel Firebase. C'est là où les données de l'application sont stockées.

    projectId: 'app-music-e1542', // Identifiant unique du projet Firebase.

    storageBucket: 'app-music-e1542.appspot.com', // URL du bucket de stockage Firebase où les fichiers tels que les images ou les vidéos peuvent être stockés.

    messagingSenderId: '180150069953', // Identifiant de l'expéditeur de messages pour Firebase Cloud Messaging (FCM), utilisé pour envoyer des notifications push.

    appId: '1:180150069953:web:25f858bcbedbd873b90240', // Identifiant unique de l'application Firebase utilisé pour suivre les installations et les événements de l'application.

  },
};