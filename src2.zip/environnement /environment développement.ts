export const environment = {
  production: false, // Indique que l'application est en mode développement. En mode développement, des outils de débogage peuvent être activés et des optimisations de production peuvent être désactivées.

  numberPage: 2, // Définit un paramètre spécifique à l'application, ici le nombre de pages. Ce paramètre pourrait être utilisé pour la gestion de la pagination ou pour configurer l'affichage de l'interface utilisateur.

  firebaseConfig: { // Contient les paramètres de configuration nécessaires pour connecter l'application à Firebase.

    apiKey: 'AIzaSyChEUg7HCRV6b4bdnrAOI4ik-SoD2wv_2w', // Clé API pour authentifier les requêtes auprès des services Firebase. Elle permet à votre application d'accéder à Firebase de manière sécurisée.

    authDomain: 'app-music-e1542.firebaseapp.com', // Domaine utilisé par Firebase Authentication pour la gestion des utilisateurs et les connexions. Il est utilisé pour l'authentification des utilisateurs dans l'application.

    databaseURL: 'https://app-music-e1542-default-rtdb.europe-west1.firebasedatabase.app', // URL de la base de données en temps réel Firebase. Cette URL permet de lire et d'écrire des données dans la base de données en temps réel.

    projectId: 'app-music-e1542', // Identifiant unique pour le projet Firebase. Il est utilisé pour identifier le projet lors de l'utilisation des services Firebase.

    storageBucket: 'app-music-e1542.appspot.com', // URL du bucket de stockage Firebase. Ce bucket est utilisé pour stocker des fichiers comme des images, vidéos ou autres types de données binaires.

    messagingSenderId: '180150069953', // Identifiant de l'expéditeur pour Firebase Cloud Messaging (FCM). Il est utilisé pour envoyer des notifications push et des messages en temps réel aux utilisateurs.

    appId: '1:180150069953:web:25f858bcbedbd873b90240', // Identifiant unique de l'application Firebase. Utilisé pour identifier votre application et suivre les événements, installations et autres interactions.

  },
};