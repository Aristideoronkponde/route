import { Injectable } from '@angular/core'; // Importe le décorateur 'Injectable' depuis Angular pour marquer la classe comme pouvant être injectée dans d'autres parties de l'application.

import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router'; // Importe les classes nécessaires pour la gestion des routes et des états de routage dans Angular. 'Router' est utilisé pour la navigation, et 'ActivatedRouteSnapshot' et 'RouterStateSnapshot' fournissent des informations sur l'état de la route actuelle.

import { AuthService } from './auth.service'; // Importe le service 'AuthService' qui contient des méthodes d'authentification et de gestion des utilisateurs.

@Injectable({
  providedIn: 'root' // Indique que ce service est fourni au niveau de l'application entière, ce qui signifie qu'il est singleton et accessible à partir de n'importe quel composant ou autre service dans l'application.
})
export class GuardService { // Définit la classe 'GuardService', qui implémente une logique de garde de route.

  constructor(private aS: AuthService, private router: Router) { } // Initialise le service avec des instances injectées d'AuthService pour vérifier l'authentification et Router pour la navigation.

  canActivate(
    route: ActivatedRouteSnapshot, // Représente l'instantané de la route activée que l'utilisateur essaie d'accéder.
    state: RouterStateSnapshot // Représente l'état actuel du routeur, y compris l'URL demandée.
  ): boolean { // La méthode 'canActivate' décide si la route peut être activée ou non, en fonction des critères d'authentification.

    if (!this.aS.isAuthenticated()) { // Vérifie si l'utilisateur n'est pas authentifié en appelant la méthode 'isAuthenticated' du service d'authentification.
      console.log('no login...'); // Affiche un message de log indiquant que l'utilisateur n'est pas connecté.

      this.router.navigate(['/login'], { // Redirige l'utilisateur vers la page de connexion si l'utilisateur n'est pas authentifié.
        queryParams: { messageError: 'Error authentification' } // Ajoute des paramètres de requête à l'URL pour afficher un message d'erreur sur la page de connexion.
      });
    } else {
      console.log('login..'); // Affiche un message de log indiquant que l'utilisateur est authentifié.
      return true; // Permet l'activation de la route si l'utilisateur est authentifié.
    }
    
    return false; // Retourne 'false' pour empêcher l'activation de la route si l'utilisateur n'est pas authentifié.
  }
}