// Importation des modules et décorateurs nécessaires depuis Angular et d'autres bibliothèques.
import {
  Component,           // Importation du décorateur Component pour définir un composant Angular.
  EventEmitter,        // Importation de EventEmitter pour émettre des événements depuis le composant.
  Input,               // Importation de Input pour recevoir des données des composants parents.
  OnChanges,           // Importation du cycle de vie OnChanges pour détecter les changements des propriétés d'entrée.
  OnInit,              // Importation du cycle de vie OnInit pour la logique d'initialisation du composant.
  Output,              // Importation de Output pour émettre des événements aux composants parents.
  SimpleChanges,       // Importation de SimpleChanges pour suivre les changements des propriétés d'entrée.
} from '@angular/core';
import { Album, List } from '../album';  // Importation des types Album et List depuis le module album.
import { CommonModule } from '@angular/common'; // Importation de CommonModule pour utiliser les directives Angular communes.
import { MatIconModule } from '@angular/material/icon'; // Importation de MatIconModule pour utiliser les icônes Material.
import { AlbumService } from '../album.service'; // Importation du service AlbumService pour gérer les opérations liées aux albums.
import { ActivatedRoute } from '@angular/router'; // Importation d'ActivatedRoute pour les données liées à la route (non utilisé dans ce code).

// Définition du composant avec son sélecteur, modèle, et styles.
@Component({
  selector: 'app-album-details',  // Sélecteur pour utiliser ce composant dans les modèles HTML.
  standalone: true,              // Indique que le composant est autonome et ne nécessite pas de module.
  imports: [CommonModule, MatIconModule], // Importation des modules nécessaires pour le composant.
  templateUrl: './album-details.component.html', // Chemin vers le modèle HTML du composant.
  styleUrl: './album-details.component.css', // Chemin vers les styles CSS du composant.
})
export class AlbumDetailsComponent implements OnInit, OnChanges {
  @Input() album?: Album; // Propriété d'entrée pour recevoir un objet album depuis le composant parent.
  @Output() onPlay: EventEmitter<Album> = new EventEmitter(); // Propriété de sortie pour émettre des événements lorsqu'un album est joué.

  albumLists: List[] = []; // Tableau pour stocker les listes de chansons liées à l'album.
  songs: string[] = []; // Tableau pour stocker les titres des chansons.

  // Injection du service AlbumService pour utiliser ses méthodes et propriétés dans le composant.
  constructor(private albumService: AlbumService) {}

  // Cycle de vie appelé une fois que le composant est initialisé.
  ngOnInit(): void {}

  // Cycle de vie appelé lorsque les propriétés liées aux données du composant changent.
  ngOnChanges(changes: SimpleChanges): void {
    if (this.album) { // Vérifie si la propriété d'entrée album a une valeur.
      this.albumService.getAlbumList(this.album.id).subscribe((albs) => { // Appelle AlbumService pour obtenir la liste des albums basée sur l'ID de l'album.
        const selectedList = albs; // Stocke la liste des albums récupérés.
        this.songs = selectedList?.list || []; // Assigne la liste des chansons à la propriété songs du composant, par défaut un tableau vide si null.
      });
    }
  }

  // Méthode pour gérer l'action de lecture d'un album.
  play(album: Album) {
    this.onPlay.emit(album); // Émet l'événement onPlay avec l'album courant.
    this.albumService.subjectAlbum.next(album); // Publie l'album sur un sujet dans AlbumService pour que d'autres parties de l'application réagissent.
  }
}