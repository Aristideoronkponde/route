import { Component, OnInit } from '@angular/core'; // Importation des décorateurs Component et OnInit depuis Angular.
import { CommonModule } from '@angular/common'; // Importation du module commun pour les fonctionnalités de base.
import { RouterModule, RouterOutlet } from '@angular/router'; // Importation des modules de routage pour les fonctionnalités de navigation.
import { AlbumsComponent } from './albums/albums.component'; // Importation du composant Albums pour l'affichage des albums.
import { Observable, interval, take, map } from 'rxjs'; // Importation des classes et opérateurs RxJS pour la gestion des observables et des transformations.

@Component({
  selector: 'app-root', // Sélecteur du composant, utilisé dans les templates pour inclure ce composant.
  standalone: true, // Indique que ce composant est autonome et peut fonctionner indépendamment.
  imports: [CommonModule, RouterOutlet, RouterModule, AlbumsComponent], // Modules importés pour être utilisés dans ce composant.
  templateUrl: './app.component.html', // Chemin vers le fichier de template HTML du composant.
  styleUrls: ['./app.component.css'], // Chemin vers le fichier de styles CSS du composant.
})
export class AppComponent implements OnInit { // Déclaration du composant et de l'interface OnInit.
  title = 'angular-app-music'; // Titre de l'application.

  timerObservable!: Observable<string>; // Déclaration d'un observable pour la minuterie, avec opérateur de confiance pour indiquer qu'il sera initialisé plus tard.
  count?: string = 'Time: 00 h 00 min 00 s'; // Variable pour stocker le temps formaté, initialisée avec une valeur par défaut.

  constructor() {} // Constructeur du composant, sans dépendances injectées.

  ngOnInit(): void { // Méthode d'initialisation appelée après que le composant soit créé.
    this.timerObservable = interval(1000).pipe( // Création d'un observable qui émet une valeur toutes les secondes.
      take(3600 * 12), // Limite le nombre d'émissions à 12 heures (43200 secondes).
      map((num) => { // Transformation des émissions en format de temps lisible.
        const hours = Math.floor(num / 3600); // Calcul des heures à partir du nombre total de secondes.
        const minutes = Math.floor(num / 60); // Calcul des minutes à partir du nombre total de secondes.
        return `Time: ${this.format(hours)} h ${this.format( // Formatage du temps en heures, minutes et secondes.
          minutes - hours * 60
        )} min ${this.format(num - minutes * 60)} s`;
      })
    );

    this.timerObservable.subscribe((time) => (this.count = time)); // Abonnement à l'observable pour mettre à jour la variable count avec le temps formaté.
  }

  format(num: number): string { // Méthode pour formater les nombres à deux chiffres.
    return (num < 10 ? '0' : '') + num; // Ajoute un zéro devant les nombres inférieurs à 10 pour assurer un format à deux chiffres.
  }
}