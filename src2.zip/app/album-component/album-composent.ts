import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Album } from '../album';
import { AlbumService } from '../album.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-album-description',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './album-description.component.html',
  styleUrls: ['./album-description.component.css'],
})
export class AlbumDescriptionComponent implements OnInit {
  album?: Album;

  constructor(
    private route: ActivatedRoute,
    private albumService: AlbumService
  ) {}

  ngOnInit(): void {
    // Récupérer l'identifiant de l'album à partir des paramètres de l'URL
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      // Appeler le service pour obtenir les détails de l'album correspondant à l'identifiant
      this.albumService.getAlbum(id).subscribe((alb) => (this.album = alb));
    }
  }
}