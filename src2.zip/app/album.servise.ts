import { Injectable } from '@angular/core';  // Importation du décorateur Injectable pour rendre le service injectable.
import { Album, List } from './album';       // Importation des types Album et List depuis le module album.
import { ALBUMS, ALBUM_LISTS } from './mock-albums'; // Importation des données simulées pour les albums et les listes d'albums (non utilisé ici).
import { environment } from '../environments/environment'; // Importation des variables d'environnement.
import { Observable, Subject, map } from 'rxjs'; // Importation des classes et opérateurs RxJS pour la gestion des observables.
import { HttpClient } from '@angular/common/http'; // Importation du client HTTP pour les requêtes (non utilisé ici).
import { db } from './firebase'; // Importation de la référence à la base de données Firebase.
import { DataSnapshot, onValue, ref } from 'firebase/database'; // Importation des fonctions Firebase pour la lecture des données.

@Injectable({
  providedIn: 'root', // Indique que ce service est disponible dans l'ensemble de l'application.
})
export class AlbumService {
  // Création d'un sujet pour gérer la page actuelle de la pagination.
  sendCurrentNumberPage = new Subject<number>();

  // Création de sujets pour émettre les albums sélectionnés et les listes d'albums.
  subjectAlbum = new Subject<Album>();
  subjectAlbums = new Subject<Album[]>();

  // Injection du client HTTP dans le constructeur du service.
  constructor(private http: HttpClient) {}

  // Méthode pour obtenir la liste de tous les albums depuis Firebase.
  getAlbums(): Observable<Album[]> {
    const albumsRef = ref(db, 'albums'); // Référence à la collection 'albums' dans Firebase.

    return new Observable<Album[]>((observer) => {
      const callback = (snapshot: DataSnapshot) => { // Fonction de rappel pour traiter les données récupérées.
        const data = snapshot.val() as Album[] | null; // Conversion des données en tableau d'albums ou null.

        if (data) {
          // Tri des albums par durée décroissante.
          const sortedAlbums = data.sort((a, b) => b.duration - a.duration);
          observer.next(sortedAlbums); // Envoi des albums triés à l'observateur.
        } else {
          observer.next([]); // Envoi d'un tableau vide si aucune donnée n'est trouvée.
        }
      };

      // Attache le listener à la référence des albums.
      const unsubscribe = onValue(albumsRef, callback);

      // Fonction de nettoyage pour détacher le listener lors de la désinscription de l'observable.
      return () => {
        unsubscribe(); // Détache le listener.
      };
    });
  }

  // Méthode pour obtenir un album spécifique par ID depuis Firebase.
  getAlbum(id: string): Observable<Album | undefined> {
    const albumRef = ref(db, 'albums/' + id); // Référence à un album spécifique par ID.

    return new Observable<Album | undefined>((observer) => {
      const callback = (snapshot: DataSnapshot) => { // Fonction de rappel pour traiter les données récupérées.
        const data = snapshot.val() as Album | null; // Conversion des données en un album ou null.
        if (data) {
          observer.next(data); // Envoi de l'album à l'observateur.
        } else {
          observer.next(undefined); // Envoi de undefined si l'album n'est pas trouvé.
        }
      };

      // Attache le listener à la référence de l'album.
      const unsubscribe = onValue(albumRef, callback);

      // Fonction de nettoyage pour détacher le listener lors de la désinscription de l'observable.
      return () => {
        unsubscribe(); // Détache le listener.
      };
    });
  }

  // Méthode pour obtenir la liste des morceaux d'un album spécifique par ID depuis Firebase.
  getAlbumList(id: string): Observable<List | undefined> {
    const albumListRef = ref(db, 'albumList/' + id); // Référence à la liste des morceaux d'un album spécifique par ID.

    return new Observable<List | undefined>((observer) => {
      const callback = (snapshot: DataSnapshot) => { // Fonction de rappel pour traiter les données récupérées.
        const data = snapshot.val() as List | null; // Conversion des données en une liste ou null.
        if (data) {
          observer.next(data); // Envoi de la liste à l'observateur.
        } else {
          observer.next(undefined); // Envoi de undefined si la liste n'est pas trouvée.
        }
      };

      // Attache le listener à la référence de la liste des morceaux.
      const unsubscribe = onValue(albumListRef, callback);

      // Fonction de nettoyage pour détacher le listener lors de la désinscription de l'observable.
      return () => {
        unsubscribe(); // Détache le listener.
      };
    });
  }

  // Méthode pour obtenir le nombre total d'albums.
  count(): Observable<number> {
    return this.getAlbums().pipe(map((albums) => albums.length)); // Utilisation de l'opérateur map pour compter le nombre d'albums.
  }

  // Méthode pour obtenir une page d'albums en utilisant la pagination.
  paginate(start: number, end: number): Observable<Album[]> {
    // Utilisation de la méthode slice pour obtenir une sous-liste des albums.
    return this.getAlbums().pipe(map((albums) => albums.slice(start, end)));
  }

  // Méthode pour rechercher des albums par titre.
  search(word: string): Observable<Album[]> {
    let re = new RegExp(word.trim(), 'gi'); // Création d'une expression régulière pour la recherche insensible à la casse.

    return this.getAlbums().pipe(
      map((albums) =>
        albums.filter((album) => album.title.match(re) && album.title.match(re)) // Filtrage des albums en fonction de la recherche.
      )
    );
  }

  /**
   * Fonction qui détermine combien d'albums seront affichés par page.
   * @returns nombre d'albums par page
   */
  paginateNumberPage(): number {
    if (typeof environment.numberPage === 'undefined') {
      throw "Attention la pagination n'est pas définie"; // Lance une erreur si le nombre d'albums par page n'est pas défini.
    }
    return environment.numberPage; // Retourne le nombre d'albums par page à partir des variables d'environnement.
  }

  // Méthode pour définir la page actuelle dans la pagination.
  currentPage(numberPage: number) {
    return this.sendCurrentNumberPage.next(numberPage); // Envoie le numéro de page actuelle au sujet.
  }

  // Méthode pour changer l'état d'un album à 'off'.
  switchOff(album: Album): void {
    album.status = 'off'; // Définit l'état de l'album sur 'off'.
  }

  // Méthode pour changer l'état d'un album à 'on'.
  switchOn(album: Album): void {
    album.status = 'on'; // Définit l'état de l'album sur 'on'.
  }
}