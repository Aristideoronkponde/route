// Importation des modules et décorateurs nécessaires depuis Angular et d'autres bibliothèques.
import { Component, OnInit } from '@angular/core'; // Importation du décorateur Component pour définir le composant et de OnInit pour le cycle de vie d'initialisation.
import { Album } from '../album'; // Importation du type Album depuis le module album.
import { CommonModule } from '@angular/common'; // Importation de CommonModule pour utiliser les directives communes d'Angular.
import { MatIconModule } from '@angular/material/icon'; // Importation de MatIconModule pour utiliser les icônes Material.
import { AlbumDetailsComponent } from '../album-details/album-details.component'; // Importation du composant AlbumDetailsComponent pour afficher les détails des albums.
import { AlbumService } from '../album.service'; // Importation du service AlbumService pour gérer les données des albums.
import { PaginateComponent } from '../paginate/paginate.component'; // Importation du composant PaginateComponent pour la pagination.
import { SearchComponent } from '../search/search.component'; // Importation du composant SearchComponent pour la recherche des albums.
import { RouterModule } from '@angular/router'; // Importation de RouterModule pour la gestion des routes (non utilisé directement dans ce code).
import { AudioPlayerComponent } from '../audio-player/audio-player.component'; // Importation du composant AudioPlayerComponent pour lire les morceaux.

@Component({
  selector: 'app-albums',  // Sélecteur pour utiliser ce composant dans les modèles HTML.
  standalone: true,       // Indique que le composant est autonome et ne nécessite pas de module.
  imports: [              // Importation des modules nécessaires pour ce composant.
    CommonModule,
    MatIconModule,
    AlbumDetailsComponent,
    AudioPlayerComponent,
    SearchComponent,
    RouterModule,
    PaginateComponent,
  ],
  templateUrl: './albums.component.html',  // Chemin vers le modèle HTML du composant.
  styleUrl: './albums.component.css',      // Chemin vers les styles CSS du composant.
})
export class AlbumsComponent implements OnInit {  // Définition de la classe du composant AlbumsComponent.
  titlePage: string = 'Page principale Album Music'; // Titre de la page.
  albums!: Album[];  // Tableau pour stocker les albums récupérés.
  selectedAlbum?: Album; // Album sélectionné, s'il y en a un.
  /** Variable pour gérer l'affichage de l'album en cours de lecture */
  status?: string; // État pour indiquer l'album actuellement en lecture.

  // Injection du service AlbumService pour accéder aux méthodes et données des albums.
  constructor(private albumService: AlbumService) {}

  // Cycle de vie appelé une fois que le composant est initialisé.
  ngOnInit(): void {
    // Récupération des albums depuis le service lors de l'initialisation du composant.
    this.albumService.getAlbums().subscribe((albums) => {
      this.albums = albums;  // Assigne les albums récupérés à la propriété albums.
    });
    // Récupération d'une page d'albums depuis le service avec pagination.
    this.albumService.paginate(0, 5).subscribe((alb) => (this.albums = alb));  // Assigne la liste paginée d'albums à la propriété albums.
  }

  // Méthode pour sélectionner un album.
  onSelect(album: Album) {
    this.selectedAlbum = album; // Assigne l'album sélectionné à la propriété selectedAlbum.
  }

  // Méthode pour gérer l'action de lecture depuis un composant enfant.
  playParent(e: Album) {
    this.status = e.id; // Met à jour l'état avec l'ID de l'album en cours de lecture.
  }

  // Méthode pour mettre à jour la liste des albums en fonction de la recherche.
  search(searchAlbums: Album[]) {
    if (searchAlbums) this.albums = searchAlbums; // Met à jour la propriété albums si des albums sont trouvés.
  }

  // Méthode pour mettre à jour la liste des albums lorsque les albums changent (émis depuis un autre composant).
  onChangeEmit(album: Album[]) {
    if (album) this.albums = album; // Met à jour la propriété albums si la nouvelle liste d'albums est disponible.
  }

  // Méthode pour gérer la pagination des albums.
  paginate($event: { start: number; end: number }) {
    this.albumService
      .paginate($event.start, $event.end) // Appelle la méthode paginate du service AlbumService avec les indices de début et de fin.
      .subscribe((albs) => (this.albums = albs)); // Met à jour la propriété albums avec la liste paginée d'albums.
  }
}