import { bootstrapApplication } from '@angular/platform-browser'; // Importe la fonction 'bootstrapApplication' depuis le package Angular, nécessaire pour démarrer l'application Angular sur le navigateur.

import { appConfig } from './app/app.config'; // Importe la configuration de l'application depuis le fichier 'app.config.ts', qui contient les paramètres nécessaires pour configurer l'application Angular.

import { AppComponent } from './app/app.component'; // Importe le composant racine 'AppComponent' depuis le fichier 'app.component.ts', qui est le point d'entrée de l'application Angular.

bootstrapApplication(AppComponent, appConfig) // Utilise la fonction 'bootstrapApplication' pour initialiser l'application Angular avec le composant racine 'AppComponent' et la configuration 'appConfig'.
  .catch((err) => console.error(err)); // Enregistre toute erreur survenue lors du démarrage de l'application dans la console du navigateur pour faciliter le débogage.